// lib/colors.dart

import 'package:flutter/material.dart';

class MyColors {
  static const Color customColor = Colors.blueAccent;
}
